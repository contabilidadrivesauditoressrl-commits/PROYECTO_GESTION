import { getStore } from "@netlify/blobs";

const STORE_NAME = "talento-market-recruitment";
const KEY = "applications-v1";
const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
});
const readAll = async (store) => (await store.get(KEY, { type: "json" })) || [];
const saveAll = async (store, items) => store.setJSON(KEY, items);

export default async (request) => {
  const store = getStore({ name: STORE_NAME });
  const method = request.method.toUpperCase();
  const adminKey = process.env.TM_ADMIN_KEY;
  const suppliedKey = request.headers.get("x-admin-key") || "";
  const isAdmin = Boolean(adminKey && suppliedKey && suppliedKey === adminKey);

  if (method === "GET") {
    if (!isAdmin) return json({ error: "Acceso no autorizado." }, 401);
    return json({ applications: await readAll(store) });
  }
  if (method !== "POST") return json({ error: "Método no permitido." }, 405);

  let body;
  try { body = await request.json(); }
  catch { return json({ error: "Solicitud inválida." }, 400); }

  const items = await readAll(store);
  if (body.action === "create") {
    const a = body.application || {};
    if (!a.name || !a.email || !a.phone || !a.ci || !Number.isInteger(Number(a.job))) {
      return json({ error: "Completa los datos obligatorios de la postulación." }, 400);
    }
    a.id = crypto.randomUUID();
    a.createdAt = new Date().toISOString();
    a.stage = "Recepción de postulación";
    a.stageHistory = ["Recepción de postulación"];
    items.push(a);
    await saveAll(store, items);
    return json({ application: a }, 201);
  }
  if (body.action === "assessment") {
    const a = items.find(x => x.id === body.applicationId);
    if (!a) return json({ error: "No se encontró la postulación." }, 404);
    a.assessment = body.assessment;
    a.stage = "Evaluación pendiente de rúbrica";
    a.rubricStatus = "Pendiente de calificación";
    a.stageHistory = [...(a.stageHistory || []), "Revisión curricular", "Entrevista inicial", "Evaluación técnica / práctica"];
    await saveAll(store, items);
    return json({ ok: true });
  }
  if (!isAdmin) return json({ error: "Acceso no autorizado." }, 401);
  if (body.action === "update") {
    const updated = body.application;
    if (!updated?.id) return json({ error: "Falta el identificador del postulante." }, 400);
    const idx = items.findIndex(x => x.id === updated.id);
    if (idx < 0) return json({ error: "No se encontró la postulación." }, 404);
    items[idx] = updated;
    await saveAll(store, items);
    return json({ ok: true });
  }
  if (body.action === "seed") {
    const demos = Array.isArray(body.applications) ? body.applications : [];
    if (demos.length !== 24) return json({ error: "Se requieren exactamente 24 postulantes demostrativos." }, 400);
    const existing = new Set(items.filter(x => x.demo).map(x => x.ci));
    let seeded = 0;
    for (const d of demos) {
      if (!existing.has(d.ci)) {
        d.id = crypto.randomUUID();
        d.stage = "Evaluación pendiente de rúbrica";
        d.rubricStatus = "Pendiente de calificación";
        d.stageHistory = ["Recepción de postulación", "Revisión curricular", "Entrevista inicial", "Evaluación técnica / práctica"];
        items.push(d);
        seeded++;
      }
    }
    await saveAll(store, items);
    return json({ seeded, applications: items });
  }
  return json({ error: "Acción no reconocida." }, 400);
};
